//just calls getSchoolsByProvince() if province is selected

//calls getSchools() if no province is selected